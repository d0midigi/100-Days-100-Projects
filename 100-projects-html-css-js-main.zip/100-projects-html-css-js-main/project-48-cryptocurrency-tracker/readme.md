<h1>Get Your API Key</h1>
For this project, we're using the public CoinGecko API which doesn't require an API key. Simply replace YOUR_API_KEY with your cryptocurrency symbol.
