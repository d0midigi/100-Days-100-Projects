Replace YOUR_API_KEY in the API URL with your actual API key from the Twelve Data service or another stock data provider.
