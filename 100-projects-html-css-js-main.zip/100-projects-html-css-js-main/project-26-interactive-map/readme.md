Get Your Access Token

1. Sign up for an access token from Mapbox.

2. Replace YOUR_ACCESS_TOKEN in script.js with your actual access token.
