Replace YOUR_APP_ID and YOUR_APP_KEY in the API URL with your actual Edamam API credentials.
