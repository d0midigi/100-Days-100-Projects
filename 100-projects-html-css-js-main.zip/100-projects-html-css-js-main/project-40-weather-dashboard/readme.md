Get Your API Key

1. Sign up for an API key from OpenWeatherMap.

2. Replace YOUR_API_KEY in script.js with your actual API key.
