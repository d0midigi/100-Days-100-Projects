Replace your_api_key_here with your actual API key from Coinbase or another cryptocurrency API provider.
