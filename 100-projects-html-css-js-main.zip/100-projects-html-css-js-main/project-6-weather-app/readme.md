Get Your API Key
Sign up for an API key from OpenWeatherMap.

Replace YOUR_API_KEY in script.js with your actual API key.
