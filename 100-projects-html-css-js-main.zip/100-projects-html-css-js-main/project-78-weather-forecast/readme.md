OpenWeatherMap API:

Sign up at OpenWeatherMap to get your free API key. Replace the apiKey variable with your key in the script.
